$(document).ready(function(){

  $( 'button' ).click(function() {
    $( "a" ).showLinkLocation();
  });

});