##CSS Positioning Demo
---

A quick demo to show the different kinds of positioning available  with CSS and what effect they have. Positioning rules covered:
- Static
- Relative
- Absolute
- Fixed

Unzip the archive and open the index file to view. Use Firebug or Chrome Developer Tools to look that the specific css rules in use.