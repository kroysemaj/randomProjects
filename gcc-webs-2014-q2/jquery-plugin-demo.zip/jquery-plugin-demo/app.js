$(document).ready(function(){

  $(window).load(function(){
    $('#raptors').raptorize();
  });

});